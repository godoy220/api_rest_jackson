require('dotenv').config();
const { Sequelize } = require('sequelize');

const conexao = new Sequelize
(process.env.DB_NAME || 'api_rest_jackson',
     process.env.DB_USER || 'root',
      process.env.DB_PASSWORD, 
    {
    dialect: 'mysql',
    host: process.env.DB_HOST || 'localhost',
    port: process.env.DB_PORT || 3306,
    logging: false
});

(async () => {
    try {
        await conexao.authenticate();
        console.log('Conexão com o banco de dados estabelecida com sucesso.');
    } catch (error) {
        console.error('Erro ao conectar ao banco de dados:', error.message);
        process.exit(1);
    }
})();

module.exports = conexao;
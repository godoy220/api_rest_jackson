const Project = require('../models/project');

class ProjectController {

    static async criarProject(req, res) {
        try {
            const { nome, descricao } = req.body;
            const project = await Project.create({ nome, descricao });
            res.status(201).json(project);
        } catch (erro) {
            res.status(500).json({ error: erro.message });
        }
    }

    static async pegarTodosProjects(req, res) {
        try {
            const projects = await Project.findAll();
            res.json(projects);
        } catch (erro) {
            res.status(500).json({ error: erro.message });
        }
    }

    static async atualizarProject(req, res) {
        try {
            const { nome, descricao } = req.body;
            const { id } = req.params;
            const project = await Project.findByPk(id);
            if (!project) {
                return res.status(404).json({ error: 'Project nao encontrado!' });
            }
            await project.update({ nome, descricao });
            res.json(project);
        } catch (erro) {
            res.status(500).json({ error: erro.message });
        }
    }

    static async deletarProject(req, res) {
        try {
            const { id } = req.params;
            const project = await Project.findByPk(id);
            if (!project) {
                return res.status(404).json({ error: 'Project nao encontrado!' });
            }
            await project.destroy();
            res.status(204).send({ message: 'Project removido!' });
        } catch (erro) {
            res.status(500).json({ error: erro.message });
        }
    }
}

module.exports = ProjectController;
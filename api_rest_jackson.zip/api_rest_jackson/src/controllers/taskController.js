const Task = require('../models/task');

class TaskController {

    static async criarTask(req, res) {
        try {
            const { titulo, status, ProjectId, UserId } = req.body;
            const task = await Task.create({ titulo, status, ProjectId, UserId });
            res.status(201).json(task);
        } catch (erro) {
            res.status(500).json({ error: erro.message });
        }
    }

    static async pegarTodasTasks(req, res) {
        try {
            const tasks = await Task.findAll();
            res.json(tasks);
        } catch (erro) {
            res.status(500).json({ error: erro.message });
        }
    }

    static async atualizarTask(req, res) {
        try {
            const { titulo, status, ProjectId, UserId } = req.body;
            const { id } = req.params;
            const task = await Task.findByPk(id);
            if (!task) {
                return res.status(404).json({ error: 'Task nao encontrada!' });
            }
            await task.update({ titulo, status, ProjectId, UserId });
            res.json(task);
        } catch (erro) {
            res.status(500).json({ error: erro.message });
        }
    }

    static async deletarTask(req, res) {
        try {
            const { id } = req.params;
            const task = await Task.findByPk(id);
            if (!task) {
                return res.status(404).json({ error: 'Task nao encontrada!' });
            }
            await task.destroy();
            res.status(204).send({ message: 'Task removida!' });
        } catch (erro) {
            res.status(500).json({ error: erro.message });
        }
    }
}

module.exports = TaskController;
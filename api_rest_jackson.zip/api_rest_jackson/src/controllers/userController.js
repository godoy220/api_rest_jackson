const User = require('../models/user');
const jwt = require('jsonwebtoken');
require('dotenv').config();

class UserController {

    static async criarUser(req, res) {
        try {
            const { nome, email, senha } = req.body;
            const novoUser = await User.create({ nome, email, senha });
            res.status(201).json(novoUser);
        } catch (erro) {
            res.status(500).json({ error: erro.message });
        }
    }

    static async pegarTodosUsers(req, res) {
        try {
            const users = await User.findAll();
            res.json(users);
        } catch (erro) {
            res.status(500).json({ error: erro.message });
        }
    }

    static async atualizarUser(req, res) {
        try {
            const { nome, email, senha } = req.body;
            const { id } = req.params;
            const user = await User.findByPk(id);
            if (!user) {
                return res.status(404).json({ error: 'User nao encontrado!' });
            }
            await user.update({ nome, email, senha });
            res.json(user);
        } catch (erro) {
            res.status(500).json({ error: erro.message });
        }
    }

    static async deletarUser(req, res) {
        try {
            const { id } = req.params;
            const user = await User.findByPk(id);
            if (!user) {
                return res.status(404).json({ error: 'User nao encontrado!' });
            }
            await user.destroy();
            res.status(204).send({ message: 'User removido!' });
        } catch (erro) {
            res.status(500).json({ error: erro.message });
        }
    }

    static async fazerLogin(req, res) {
        try {
            const { email, senha } = req.body;
            const user = await User.findOne({ where: { email } });

            if (!user || !(await user.validarSenha(senha))) {
                return res.status(401).json({ error: 'Credenciais invalidas' });
            }

            const token = jwt.sign({ userId: user.id }, process.env.JWT_SECRET, { expiresIn: '1h' });

            res.json({ message: 'Login ok!', token });
        } catch (erro) {
            res.status(500).json({ error: erro.message });
        }
    }
}

module.exports = UserController;
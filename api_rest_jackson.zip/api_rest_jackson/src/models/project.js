const { DataTypes } = require('sequelize');
const conexao = require('../config/database');

const Project = conexao.define('project', {
    nome: {
        type: DataTypes.STRING,
        allowNull: false
    },
    descricao: {
        type: DataTypes.TEXT
    }
}, {
    tableName: 'projects'
});

module.exports = Project;
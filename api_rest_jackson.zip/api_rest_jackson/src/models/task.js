const { DataTypes } = require('sequelize');
const conexao = require('../config/database');

const Task = conexao.define('task', {
    titulo: {
        type: DataTypes.STRING,
        allowNull: false
    },
    status: {
        type: DataTypes.STRING,
        allowNull: false,
        defaultValue: 'Pendente'
    }
}, {
    tableName: 'tasks'
});

module.exports = Task;
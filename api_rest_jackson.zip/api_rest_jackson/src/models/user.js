const { DataTypes } = require('sequelize');
const conexao = require('../config/database');
const bcrypt = require('bcrypt');

const User = conexao.define('user', {
    nome: {
        type: DataTypes.STRING,
        allowNull: false
    },
    email: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: true
    },
    senha: {
        type: DataTypes.STRING,
        allowNull: false
    }
}, {
    tableName: 'users',
    hooks: {
        beforeCreate: async (user) => {
            if (user.senha) {
                const salt = await bcrypt.genSalt(10);
                user.senha = await bcrypt.hash(user.senha, salt);
            }
        }
    }
});

User.prototype.validarSenha = async function(senha) {
    return await bcrypt.compare(senha, this.senha);
};

module.exports = User;
require('dotenv').config();
const express = require('express');
const ProjectController = require('./controllers/projectController');
const TaskController = require('./controllers/taskController');
const UserController = require('./controllers/userController');
const conexao = require('./config/database');
const Project = require('./models/project');
const Task = require('./models/task');
const User = require('./models/user');

const app = express();

app.use(express.json());

async function conectarBanco() {
    try {
        await conexao.authenticate();
        console.log('Banco conectado!');

        await conexao.sync({ force: false });
        console.log('Tabelas criadas (se necessário)!');

        Project.hasMany(Task, { foreignKey: 'ProjectId' });
        Task.belongsTo(Project, { foreignKey: 'ProjectId' });
        User.hasMany(Task, { foreignKey: 'UserId' });
        Task.belongsTo(User, { foreignKey: 'UserId' });

    } catch (erro) {
        console.error('Erro ao conectar o banco:', erro);
    }
}

conectarBanco();

app.get('/', (_, res) => {
    res.send('Oi Mundo!');
});

app.post('/users', UserController.criarUser);
app.get('/users', UserController.pegarTodosUsers);
app.put('/users/:id', UserController.atualizarUser);
app.delete('/users/:id', UserController.deletarUser);
app.post('/login', UserController.fazerLogin);

app.post('/projects', ProjectController.criarProject);
app.get('/projects', ProjectController.pegarTodosProjects);
app.put('/projects/:id', ProjectController.atualizarProject);
app.delete('/projects/:id', ProjectController.deletarProject);

app.post('/tasks', TaskController.criarTask);
app.get('/tasks', TaskController.pegarTodasTasks);
app.put('/tasks/:id', TaskController.atualizarTask);
app.delete('/tasks/:id', TaskController.deletarTask);

app.listen(3000, () => {
    console.log('Servidor rodando na porta 3000');
});